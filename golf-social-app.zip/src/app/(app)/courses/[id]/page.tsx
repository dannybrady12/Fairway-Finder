import { createServerSupabaseClient } from '@/lib/supabase';
import { Course, CourseReview, ReviewLevel } from '@/types/database.types';
import Link from 'next/link';
import Image from 'next/image';
import { MapPin, Golf, Calendar } from 'lucide-react';
import ReviewFeed from '@/components/reviews/ReviewFeed';
import CourseHoleInfo from '@/components/courses/CourseHoleInfo';
import CourseWeather from '@/components/courses/CourseWeather';
import ReviewSubmitButton from '@/components/reviews/ReviewSubmitButton';

interface CourseDetailPageProps {
  params: {
    id: string;
  };
}

export default async function CourseDetailPage({ params }: CourseDetailPageProps) {
  const supabase = createServerSupabaseClient();
  
  // Get current user
  const { data: { user } } = await supabase.auth.getUser();
  
  // Fetch course details
  const { data: course } = await supabase
    .from('courses')
    .select('*')
    .eq('id', params.id)
    .single();
  
  // Fetch course holes
  const { data: holes } = await supabase
    .from('course_holes')
    .select('*')
    .eq('course_id', params.id)
    .order('hole_number', { ascending: true });
  
  // Fetch course images
  const { data: images } = await supabase
    .from('course_images')
    .select('*')
    .eq('course_id', params.id)
    .order('is_primary', { ascending: false });
  
  // Fetch course reviews with user info
  const { data: reviews } = await supabase
    .from('course_reviews')
    .select('*, user:users(*)')
    .eq('course_id', params.id)
    .order('created_at', { ascending: false });
  
  // Check if current user has already reviewed this course
  const userReview = user ? reviews?.find(review => review.user_id === user.id) : null;
  
  // Calculate review stats
  const reviewStats = {
    total: reviews?.length || 0,
    loved_it: reviews?.filter(r => r.review_level === 'loved_it').length || 0,
    liked_it: reviews?.filter(r => r.review_level === 'liked_it').length || 0,
    ok: reviews?.filter(r => r.review_level === 'ok').length || 0,
  };
  
  // Get most common tags
  const allTags = reviews?.flatMap(review => review.tags || []) || [];
  const tagCounts = allTags.reduce((acc: Record<string, number>, tag) => {
    acc[tag] = (acc[tag] || 0) + 1;
    return acc;
  }, {});
  
  const popularTags = Object.entries(tagCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([tag]) => tag);

  if (!course) {
    return (
      <div className="max-w-4xl mx-auto text-center py-12">
        <h1 className="text-2xl font-bold text-gray-900 mb-4">Course Not Found</h1>
        <p className="text-gray-600 mb-6">The course you're looking for doesn't exist or has been removed.</p>
        <Link 
          href="/courses" 
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700"
        >
          Back to Courses
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      {/* Course header */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
        {images && images.length > 0 && (
          <div className="relative h-64 w-full">
            <Image
              src={images[0].image_url}
              alt={course.name}
              fill
              className="object-cover"
            />
          </div>
        )}
        
        <div className="p-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{course.name}</h1>
          
          <div className="flex items-center text-gray-600 mb-4">
            <MapPin className="h-5 w-5 mr-1" />
            <span>{[course.address, course.city, course.state, course.postal_code].filter(Boolean).join(', ')}</span>
          </div>
          
          <div className="flex flex-wrap gap-3 mb-4">
            {course.par && (
              <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                <Golf className="h-4 w-4 mr-1" />
                Par {course.par}
              </span>
            )}
            {course.total_holes && (
              <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
                {course.total_holes} Holes
              </span>
            )}
            {course.rating && course.slope && (
              <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-purple-100 text-purple-800">
                Rating: {course.rating} / Slope: {course.slope}
              </span>
            )}
          </div>
          
          {course.description && (
            <p className="text-gray-700 mb-4">{course.description}</p>
          )}
          
          <div className="flex flex-wrap gap-4">
            {course.website && (
              <a 
                href={course.website} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-green-600 hover:text-green-800 font-medium"
              >
                Visit Website
              </a>
            )}
            <Link 
              href={`/scoring/new?course=${course.id}`}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700"
            >
              <Calendar className="h-4 w-4 mr-2" />
              Start a Round
            </Link>
          </div>
        </div>
      </div>
      
      {/* Course content in tabs */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
        <div className="border-b border-gray-200">
          <nav className="flex -mb-px">
            <a href="#reviews" className="border-green-500 text-green-600 whitespace-nowrap py-4 px-6 border-b-2 font-medium text-sm">
              Reviews
            </a>
            <a href="#holes" className="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-6 border-b-2 font-medium text-sm">
              Hole Details
            </a>
            <a href="#weather" className="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-6 border-b-2 font-medium text-sm">
              Weather
            </a>
          </nav>
        </div>
        
        {/* Reviews section */}
        <div id="reviews" className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold">Course Reviews</h2>
            {!userReview && user && (
              <ReviewSubmitButton courseId={course.id} />
            )}
          </div>
          
          {/* Review stats */}
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-green-600">{reviewStats.loved_it}</div>
                <div className="text-sm text-gray-500">Loved It</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-blue-500">{reviewStats.liked_it}</div>
                <div className="text-sm text-gray-500">Liked It</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-500">{reviewStats.ok}</div>
                <div className="text-sm text-gray-500">OK</div>
              </div>
            </div>
            
            {popularTags.length > 0 && (
              <div className="mt-4 pt-4 border-t border-gray-200">
                <div className="text-sm text-gray-500 mb-2">Popular tags:</div>
                <div className="flex flex-wrap gap-2">
                  {popularTags.map(tag => (
                    <span key={tag} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          {/* Review feed */}
          {reviews && reviews.length > 0 ? (
            <ReviewFeed reviews={reviews} />
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-500">No reviews yet. Be the first to review this course!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
