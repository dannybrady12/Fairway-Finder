import { createServerSupabaseClient } from '@/lib/supabase';
import { redirect } from 'next/navigation';
import ReviewForm from '@/components/reviews/ReviewForm';

interface ReviewPageProps {
  params: {
    id: string;
  };
}

export default async function ReviewPage({ params }: ReviewPageProps) {
  const supabase = createServerSupabaseClient();
  
  // Check if user is authenticated
  const { data: { user } } = await supabase.auth.getUser();
  
  if (!user) {
    redirect('/auth/login');
  }
  
  // Fetch course details
  const { data: course } = await supabase
    .from('courses')
    .select('*')
    .eq('id', params.id)
    .single();
  
  if (!course) {
    redirect('/courses');
  }
  
  return (
    <div className="max-w-4xl mx-auto py-6">
      <ReviewForm course={course} />
    </div>
  );
}
