import { createServerSupabaseClient } from '@/lib/supabase';
import { Course } from '@/types/database.types';
import Link from 'next/link';
import { Search, MapPin, Star } from 'lucide-react';

export default async function CoursesPage() {
  const supabase = createServerSupabaseClient();
  
  // Fetch courses with their average rating
  const { data: courses } = await supabase
    .from('courses')
    .select('*, course_reviews(*)')
    .order('name', { ascending: true })
    .limit(20);

  // Calculate average rating for each course
  const coursesWithRating = courses?.map((course: any) => {
    const reviews = course.course_reviews || [];
    const totalRating = reviews.reduce((sum: number, review: any) => sum + review.rating, 0);
    const averageRating = reviews.length > 0 ? totalRating / reviews.length : 0;
    
    return {
      ...course,
      average_rating: averageRating,
      review_count: reviews.length
    };
  }) || [];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Golf Courses</h1>
        <Link 
          href="/courses/map" 
          className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
        >
          View Map
        </Link>
      </div>
      
      {/* Search bar */}
      <div className="relative mb-8">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type="text"
          placeholder="Search courses by name or location..."
          className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:ring-green-500 focus:border-green-500"
        />
      </div>
      
      {/* Course list */}
      <div className="space-y-4">
        {coursesWithRating.length > 0 ? (
          coursesWithRating.map((course: Course & { average_rating: number, review_count: number }) => (
            <Link 
              key={course.id} 
              href={`/courses/${course.id}`}
              className="block bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
            >
              <div className="p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h2 className="text-xl font-semibold text-gray-900">{course.name}</h2>
                    {course.city && course.state && (
                      <div className="flex items-center text-gray-600 mt-1">
                        <MapPin className="h-4 w-4 mr-1" />
                        <span>{course.city}, {course.state}</span>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center">
                    <div className="flex items-center mr-2">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={`h-4 w-4 ${
                            i < Math.floor(course.average_rating) 
                              ? 'text-yellow-400 fill-yellow-400' 
                              : i < Math.ceil(course.average_rating) && i > Math.floor(course.average_rating)
                                ? 'text-yellow-400 fill-yellow-400 opacity-50'
                                : 'text-gray-300'
                          }`} 
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-600">({course.review_count})</span>
                  </div>
                </div>
                <div className="mt-2 flex flex-wrap gap-2">
                  {course.par && (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      Par {course.par}
                    </span>
                  )}
                  {course.total_holes && (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      {course.total_holes} Holes
                    </span>
                  )}
                </div>
              </div>
            </Link>
          ))
        ) : (
          <div className="bg-white rounded-lg shadow p-6 text-center">
            <p className="text-gray-500">No courses found. Try a different search.</p>
          </div>
        )}
      </div>
    </div>
  );
}
