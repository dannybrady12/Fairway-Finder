import ClientHomePage from '@/components/feed/ClientHomePage';

export default function HomePage() {
  return <ClientHomePage />;
}
